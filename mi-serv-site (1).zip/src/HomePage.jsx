import React from "react";

export default function HomePage() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Maintenance & Installation Services Ltd</h1>
      <p>Fire & Security Specialists You Can Rely On</p>
    </div>
  );
}